package com.example.mockupjorge111

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView

class AccessControlActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_access_control)

        val btnVisitor = findViewById<MaterialCardView>(R.id.btnVisitorRegistration)
        val btnLogbook = findViewById<MaterialCardView>(R.id.btnLogbook)

        btnVisitor.setOnClickListener {
            // Aquí pones tu navegación o acción
            Toast.makeText(this, "Abriendo Registro...", Toast.LENGTH_SHORT).show()
        }

        btnLogbook.setOnClickListener {
            Toast.makeText(this, "Abriendo Bitácora...", Toast.LENGTH_SHORT).show()
        }
    }
}