package com.example.mockupjorge111

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class LogbookActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_logbook)

        // Aquí podrías cargar los datos de una API o Base de Datos
    }
}