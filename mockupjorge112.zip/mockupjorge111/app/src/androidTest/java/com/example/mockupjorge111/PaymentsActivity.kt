package com.example.mockupjorge111

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity
import com.example.mockupjorge111.R
import com.google.android.material.tabs.TabLayout

class PaymentsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payments)

        val tabLayout = findViewById<TabLayout>(R.id.tabLayout)
        val emptyState = findViewById<LinearLayout>(R.id.emptyStateLayout)
        val listScroll = findViewById<ScrollView>(R.id.paymentsListScroll)

        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                if (tab?.position == 0) {
                    emptyState.visibility = View.VISIBLE
                    listScroll.visibility = View.GONE
                } else {
                    emptyState.visibility = View.GONE
                    listScroll.visibility = View.VISIBLE
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }
}