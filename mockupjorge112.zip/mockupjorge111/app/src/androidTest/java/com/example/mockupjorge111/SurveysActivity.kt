package com.example.mockupjorge111

import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity
import com.example.mockupjorge111.R

class SurveysActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_surveys)

        val emptyState = findViewById<LinearLayout>(R.id.emptySurveysLayout)
        val listScroll = findViewById<ScrollView>(R.id.surveysListScroll)

        // SIMULACIÓN: Cambia a 'true' para ver la encuesta, 'false' para ver pantalla vacía
        val hayEncuestas = true

        if (hayEncuestas) {
            emptyState.visibility = View.GONE
            listScroll.visibility = View.VISIBLE
        } else {
            emptyState.visibility = View.VISIBLE
            listScroll.visibility = View.GONE
        }
    }
}