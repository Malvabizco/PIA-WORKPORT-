package com.example.mockupjorge111
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView

class VisitorListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_visitor_list)

        val btnFrecuente = findViewById<MaterialCardView>(R.id.btnFrecuente)
        val expandableLayout = findViewById<LinearLayout>(R.id.expandableLayout)
        val imgArrow = findViewById<ImageView>(R.id.imgArrow)

        btnFrecuente.setOnClickListener {
            if (expandableLayout.visibility == View.GONE) {
                expandableLayout.visibility = View.VISIBLE
                imgArrow.setImageResource(R.drawable.ic_arrow_up) // Cambia flecha hacia arriba
            } else {
                expandableLayout.visibility = View.GONE
                imgArrow.setImageResource(R.drawable.ic_arrow_down) // Cambia flecha hacia abajo
            }
        }
    }
}