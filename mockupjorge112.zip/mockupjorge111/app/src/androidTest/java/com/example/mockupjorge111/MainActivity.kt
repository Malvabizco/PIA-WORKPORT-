package com.example.mockupjorge111

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView
import com.example.mockupjorge111.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Esta es la pantalla del menú

        // Configurar botón de Control de Acceso
        val btnControlAcceso = findViewById<MaterialCardView>(R.id.btnControlAcceso)
        btnControlAcceso.setOnClickListener {
            val intent = Intent(this, AccessControlActivity::class.java)
            startActivity(intent)
        }

        // Configurar botón de Pagos
        val btnPagos = findViewById<MaterialCardView>(R.id.btnPagos)
        btnPagos.setOnClickListener {
            val intent = Intent(this, PaymentsActivity::class.java)
            startActivity(intent)
        }

        // Configurar botón de Encuestas
        val btnEncuestas = findViewById<MaterialCardView>(R.id.btnEncuestas)
        btnEncuestas.setOnClickListener {
            val intent = Intent(this, SurveysActivity::class.java)
            startActivity(intent)
        }
    }
}