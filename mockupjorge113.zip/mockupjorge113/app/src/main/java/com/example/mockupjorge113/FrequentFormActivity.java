package com.example.mockupjorge113;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.mockupjorge113.R;

public class FrequentFormActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frequent_form);

        ImageView btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        EditText etNombre = findViewById(R.id.etFrequentName);
        EditText etDias = findViewById(R.id.etFrequentDays); // Ejemplo: Lunes a Viernes
        Button btnGuardar = findViewById(R.id.btnSaveFrequent);

        if (btnGuardar != null) {
            btnGuardar.setOnClickListener(v -> {
                String nombre = etNombre.getText().toString().trim();
                if (nombre.isEmpty()) {
                    Toast.makeText(this, "Ingresa el nombre de la persona", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, nombre + " ha sido registrado como visitante frecuente", Toast.LENGTH_LONG).show();
                    finish();
                }
            });
        }
    }
}
