package com.example.mockupjorge113;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.mockupjorge113.R;

public class SurveysActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_surveys);

        LinearLayout emptySurveys = findViewById(R.id.emptySurveysLayout);
        ScrollView surveysList = findViewById(R.id.surveysListScroll);

        // Control manual para pruebas
        boolean hayEncuestasActivas = true;

        if (hayEncuestasActivas) {
            emptySurveys.setVisibility(View.GONE);
            surveysList.setVisibility(View.VISIBLE);
        } else {
            emptySurveys.setVisibility(View.VISIBLE);
            surveysList.setVisibility(View.GONE);
        }
    }
}