package com.example.mockupjorge113;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.example.mockupjorge113.R;

public class VisitorListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visitor_list);

        // Botón para regresar
        ImageView btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // Botón flotante (+) para añadir nuevo visitante
        FloatingActionButton fabAdd = findViewById(R.id.fabAddVisitor);
        if (fabAdd != null) {
            fabAdd.setOnClickListener(v -> {
                Intent intent = new Intent(this, VisitorRegistrationActivity.class);
                startActivity(intent);
            });
        }

        // Simulación: Si no hay visitantes, podríamos mostrar un layout de "vacio"
        LinearLayout emptyState = findViewById(R.id.emptyVisitorsLayout);
        View visitorList = findViewById(R.id.visitorListScroll);

        boolean hayVisitantes = true; // Cambia a false para probar el estado vacío

        if (hayVisitantes) {
            if (emptyState != null) emptyState.setVisibility(View.GONE);
            if (visitorList != null) visitorList.setVisibility(View.VISIBLE);
        } else {
            if (emptyState != null) emptyState.setVisibility(View.VISIBLE);
            if (visitorList != null) visitorList.setVisibility(View.GONE);
        }
    }
}
