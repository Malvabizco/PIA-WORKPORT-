package com.example.mockupjorge113;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.card.MaterialCardView;
import android.widget.ImageView;
import com.example.mockupjorge113.R;

public class AccessControlActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_access_control);

        // Botón para regresar al menú principal
        ImageView btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // Botón Registro de Visitantes
        MaterialCardView btnRegistro = findViewById(R.id.btnVisitorRegistration);
        if (btnRegistro != null) {
            btnRegistro.setOnClickListener(v -> {
                Intent intent = new Intent(this, VisitorRegistrationActivity.class);
                startActivity(intent);
            });
        }

        // Botón Bitácora
        MaterialCardView btnBitacora = findViewById(R.id.btnLogbook);
        if (btnBitacora != null) {
            btnBitacora.setOnClickListener(v -> {
                Intent intent = new Intent(this, LogbookActivity.class);
                startActivity(intent);
            });
        }
    }
}