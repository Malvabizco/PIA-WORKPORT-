package com.example.mockupjorge113;


import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.mockupjorge113.R;

public class VisitorRegistrationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visitor_registration);

        // Botón para regresar
        ImageView btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // Referencias a los campos del formulario
        EditText etNombre = findViewById(R.id.etVisitorName);
        EditText etMotivo = findViewById(R.id.etVisitReason);
        Button btnGuardar = findViewById(R.id.btnSaveVisitor);

        // Acción al presionar el botón Guardar
        if (btnGuardar != null) {
            btnGuardar.setOnClickListener(v -> {
                String nombre = etNombre.getText().toString().trim();

                if (nombre.isEmpty()) {
                    Toast.makeText(this, "Por favor ingresa el nombre del visitante", Toast.LENGTH_SHORT).show();
                } else {
                    // Aquí iría la lógica para guardar en base de datos o generar QR
                    Toast.makeText(this, "Registro exitoso para: " + nombre, Toast.LENGTH_LONG).show();
                    finish(); // Cierra la pantalla y vuelve atrás
                }
            });
        }
    }
}
