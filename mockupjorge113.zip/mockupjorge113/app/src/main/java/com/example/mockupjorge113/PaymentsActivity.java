package com.example.mockupjorge113;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.tabs.TabLayout;
import com.example.mockupjorge113.R;

public class PaymentsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payments);

        TabLayout tabLayout = findViewById(R.id.tabLayout);
        final LinearLayout emptyState = findViewById(R.id.emptyStateLayout);
        final ScrollView paymentsList = findViewById(R.id.paymentsListScroll);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getPosition() == 0) { // Pestaña "Pendientes"
                    emptyState.setVisibility(View.VISIBLE);
                    paymentsList.setVisibility(View.GONE);
                } else { // Pestaña "Pagado"
                    emptyState.setVisibility(View.GONE);
                    paymentsList.setVisibility(View.VISIBLE);
                }
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}
            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }
}