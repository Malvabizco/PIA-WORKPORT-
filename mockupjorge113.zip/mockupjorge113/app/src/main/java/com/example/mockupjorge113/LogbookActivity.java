package com.example.mockupjorge113;



import android.os.Bundle;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.mockupjorge113.R;

public class LogbookActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logbook);

        ImageView btnBack = findViewById(R.id.btnBack); // Asegúrate de tener este ID en el XML
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }
    }
}
