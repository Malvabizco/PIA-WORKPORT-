package com.example.mockupjorge113;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.card.MaterialCardView;
import com.example.mockupjorge113.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Botón Control de Acceso
        MaterialCardView btnControlAcceso = findViewById(R.id.btnControlAcceso);
        btnControlAcceso.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AccessControlActivity.class);
            startActivity(intent);
        });

        // Botón Pagos
        MaterialCardView btnPagos = findViewById(R.id.btnPagos);
        btnPagos.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PaymentsActivity.class);
            startActivity(intent);
        });

        // Botón Encuestas
        MaterialCardView btnEncuestas = findViewById(R.id.btnEncuestas);
        btnEncuestas.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SurveysActivity.class);
            startActivity(intent);
        });
    }
}