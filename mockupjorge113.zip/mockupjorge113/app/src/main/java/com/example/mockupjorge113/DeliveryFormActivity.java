package com.example.mockupjorge113;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.mockupjorge113.R;

public class DeliveryFormActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_form);

        // Botón regresar
        ImageView btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        // Campos del formulario
        EditText etEmpresa = findViewById(R.id.etCompany); // Ejemplo: Amazon
        EditText etPaquetes = findViewById(R.id.etPackageCount);
        Button btnGenerar = findViewById(R.id.btnGenerateDeliveryAccess);

        if (btnGenerar != null) {
            btnGenerar.setOnClickListener(v -> {
                String empresa = etEmpresa.getText().toString().trim();
                if (empresa.isEmpty()) {
                    Toast.makeText(this, "Ingresa la empresa de mensajería", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Acceso creado para entrega de " + empresa, Toast.LENGTH_LONG).show();
                    finish();
                }
            });
        }
    }
}
