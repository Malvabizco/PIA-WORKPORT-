package com.example.pia_claseordinaria;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ComplaintsActivity extends AppCompatActivity {

    private EditText editTextQueja, editTextSugerencia;
    private Button buttonSendQueja, buttonSendSugerencia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaints);

        editTextQueja = findViewById(R.id.editTextQueja);
        editTextSugerencia = findViewById(R.id.editTextSugerencia);
        buttonSendQueja = findViewById(R.id.buttonSendQueja);
        buttonSendSugerencia = findViewById(R.id.buttonSendSugerencia);

        buttonSendQueja.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String queja = editTextQueja.getText().toString().trim();
                if (!queja.isEmpty()) {
                    Toast.makeText(ComplaintsActivity.this, "Queja enviada: " + queja, Toast.LENGTH_SHORT).show();
                    editTextQueja.setText("");
                } else {
                    Toast.makeText(ComplaintsActivity.this, "Por favor escribe una queja", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonSendSugerencia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sugerencia = editTextSugerencia.getText().toString().trim();
                if (!sugerencia.isEmpty()) {
                    Toast.makeText(ComplaintsActivity.this, "Sugerencia enviada: " + sugerencia, Toast.LENGTH_SHORT).show();
                    editTextSugerencia.setText("");
                } else {
                    Toast.makeText(ComplaintsActivity.this, "Por favor escribe una sugerencia", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
