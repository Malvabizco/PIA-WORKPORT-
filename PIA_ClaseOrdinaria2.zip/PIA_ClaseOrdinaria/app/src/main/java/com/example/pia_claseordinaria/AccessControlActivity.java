package com.example.pia_claseordinaria;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class AccessControlActivity extends AppCompatActivity {

    private ImageView imageViewQR;
    private TextView textViewQRStatus, textViewValidity, textViewHistoryTitle, historyDateTime, historyKey;
    private Button buttonGenerateQR;
    private View cardHistoryItem;
    private ImageButton buttonBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_access_control);

        imageViewQR = findViewById(R.id.imageViewQR);
        textViewQRStatus = findViewById(R.id.textViewQRStatus);
        textViewValidity = findViewById(R.id.textViewValidity);
        textViewHistoryTitle = findViewById(R.id.textViewHistoryTitle);
        historyDateTime = findViewById(R.id.historyDateTime);
        historyKey = findViewById(R.id.historyKey);
        buttonGenerateQR = findViewById(R.id.buttonGenerateQR);
        cardHistoryItem = findViewById(R.id.cardHistoryItem);
        buttonBack = findViewById(R.id.buttonBack);

        buttonBack.setOnClickListener(v -> finish());

        buttonGenerateQR.setOnClickListener(v -> generateAccessQR());
    }

    private void generateAccessQR() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String userEmail = (user != null && user.getEmail() != null) ? user.getEmail() : "usuario_desconocido";
        
        // Si es un mock login (bypass)
        String mockEmail = getIntent().getStringExtra("MOCK_USER_EMAIL");
        if (user == null && mockEmail != null) {
            userEmail = mockEmail;
        }

        String accessKey = generateRandomKey(8);
        String currentDate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

        String qrData = "Usuario: " + userEmail + "\n" +
                        "Clave: " + accessKey + "\n" +
                        "Fecha: " + currentDate + "\n" +
                        "Hora: " + currentTime;

        try {
            Bitmap bitmap = encodeAsBitmap(qrData);
            imageViewQR.setImageBitmap(bitmap);
            
            // Actualizar textos y visibilidad
            textViewQRStatus.setText("¡Código generado con éxito!\nEste código es personal e intransferible.");
            textViewValidity.setVisibility(View.VISIBLE);
            
            // Mostrar Historial
            textViewHistoryTitle.setVisibility(View.VISIBLE);
            cardHistoryItem.setVisibility(View.VISIBLE);
            historyDateTime.setText(currentDate + " - " + currentTime.substring(0, 5));
            historyKey.setText("Clave: " + accessKey);

            Toast.makeText(this, "QR Generado", Toast.LENGTH_SHORT).show();

        } catch (WriterException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error al generar QR", Toast.LENGTH_SHORT).show();
        }
    }

    private String generateRandomKey(int length) {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        return sb.toString();
    }

    private Bitmap encodeAsBitmap(String str) throws WriterException {
        QRCodeWriter writer = new QRCodeWriter();
        BitMatrix bitMatrix = writer.encode(str, BarcodeFormat.QR_CODE, 512, 512);
        int width = bitMatrix.getWidth();
        int height = bitMatrix.getHeight();
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
        for (int x = 0; width > x; x++) {
            for (int y = 0; height > y; y++) {
                bitmap.setPixel(x, y, bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE);
            }
        }
        return bitmap;
    }
}
