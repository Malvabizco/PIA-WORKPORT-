package com.example.pia_claseordinaria;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AnnouncementsActivity extends AppCompatActivity {

    private Button buttonMarkAsRead;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_announcements);

        buttonMarkAsRead = findViewById(R.id.buttonMarkAsRead);

        buttonMarkAsRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(AnnouncementsActivity.this, "Todos los comunicados marcados como leídos", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
