package com.example.pia_claseordinaria;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ProfileActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private ImageButton buttonConfig;
    private MaterialCardView cardReservations, cardAnnouncements, cardComplaints, cardAccessControl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);
        buttonConfig = findViewById(R.id.buttonConfig);
        cardReservations = findViewById(R.id.cardReservations);
        cardAnnouncements = findViewById(R.id.cardAnnouncements);
        cardComplaints = findViewById(R.id.cardComplaints);
        cardAccessControl = findViewById(R.id.cardAccessControl);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        
        // Obtener email si viene de un mock login
        String mockEmail = getIntent().getStringExtra("MOCK_USER_EMAIL");

        // Configurar el botón de engranaje para abrir el sidebar
        buttonConfig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.END);
            }
        });

        // Configurar el click en la tarjeta de Reservaciones
        cardReservations.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ProfileActivity.this, ReservationsActivity.class));
            }
        });

        // Configurar el click en la tarjeta de Comunicados
        cardAnnouncements.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ProfileActivity.this, AnnouncementsActivity.class));
            }
        });

        // Configurar el click en la tarjeta de Quejas y Sugerencias
        cardComplaints.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ProfileActivity.this, ComplaintsActivity.class));
            }
        });

        // Configurar el click en la tarjeta de Control de Acceso
        cardAccessControl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, AccessControlActivity.class);
                if (mockEmail != null) {
                    intent.putExtra("MOCK_USER_EMAIL", mockEmail);
                }
                startActivity(intent);
            }
        });

        // Configurar botones dentro del sidebar
        setupSidebar(user, mockEmail);
    }

    private void setupSidebar(FirebaseUser user, String mockEmail) {
        Button btnNightMode = findViewById(R.id.nav_night_mode);
        Button btnAccount = findViewById(R.id.nav_account);
        Button btnRegisterAdmin = findViewById(R.id.nav_register_admin);
        Button btnLogout = findViewById(R.id.nav_logout);

        String currentEmail = "";
        if (user != null) {
            currentEmail = user.getEmail();
        } else if (mockEmail != null) {
            currentEmail = mockEmail;
        }

        // Lógica para mostrar "Registrar Admin" solo si el email contiene "admin" o es el mock de admin
        if (currentEmail != null && (currentEmail.contains("admin") || currentEmail.equals("usuario2@gmail.com"))) {
            btnRegisterAdmin.setVisibility(View.VISIBLE);
        } else {
            btnRegisterAdmin.setVisibility(View.GONE);
        }

        btnNightMode.setOnClickListener(v -> {
            Toast.makeText(this, "Modo Nocturno (Próximamente)", Toast.LENGTH_SHORT).show();
            drawerLayout.closeDrawer(GravityCompat.END);
        });

        final String finalEmail = (currentEmail != null && !currentEmail.isEmpty()) ? currentEmail : "No identificado";
        btnAccount.setOnClickListener(v -> {
            Toast.makeText(this, "Cuenta: " + finalEmail, Toast.LENGTH_SHORT).show();
            drawerLayout.closeDrawer(GravityCompat.END);
        });

        btnRegisterAdmin.setOnClickListener(v -> {
            startActivity(new Intent(ProfileActivity.this, RegisterActivity.class));
            drawerLayout.closeDrawer(GravityCompat.END);
        });

        btnLogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(ProfileActivity.this, MainActivity.class));
            finish();
        });
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.END)) {
            drawerLayout.closeDrawer(GravityCompat.END);
        } else {
            super.onBackPressed();
        }
    }
}
